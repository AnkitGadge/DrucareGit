package com.ratingdata.ratingdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RatingdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(RatingdataApplication.class, args);
	}

}
