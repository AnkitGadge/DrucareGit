package com.ratingdata.ratingdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingdataApplicationTests {

	@Test
	void contextLoads() {
	}

}
